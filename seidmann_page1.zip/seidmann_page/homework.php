<!DOCTYPE html>
<html>
<?php
include('header.php'); // Inclui o cabeçalho
?>

<body>
    <h1>sorry we are still  working here</h1>
<img src="https://media1.giphy.com/media/Mah9dFWo1WZX0WM62Q/giphy.gif?cid=ecf05e47fdn226a759f7s1kq55d3x5x0c0qmk37p28i5iy6o&ep=v1_gifs_search&rid=giphy.gif&ct=g" alt="stillbuilding">
    <?php
include('footer.php'); // Inclui o rodapé
?>
</body>
</html>